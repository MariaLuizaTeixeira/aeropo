<?php

header(__DIR__ . "/view/home.php");
?>