<?php

require_once(__DIR__ . "/view/include/header.php");
?>

<?php
require_once(__DIR__ . "/view/include/footer.php");
?>