<?php

require_once(__DIR__ . "/include/header.php");
require_once(__DIR__ . "/include/menu.php");
require_once(__DIR__ . "/../controller/VooController.php");
require_once(__DIR__ . "/../util/config.php");

$vooController = new VooController();
$voosAleatorios = $vooController->listarAleatoriamente();

?>

<div class="imagem justify-content-center">
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtTiQ_DY-ys9quVMZsnGukRr5EFmxT5pKcgjZiIpzCKQ&s=10" alt="">
    <h3>Explore o mundo</h3>
</div>

<div class="principais-destinos">
    <h6>Principais destinos</h6>
    <?php foreach($voosAleatorios as $voo): ?>
    <div class="card" style="width: 18rem;">
        <img class="card-img-top" src="<?= $voo->getImagem() ?>" alt="Card image cap">
        <div class="card-body">
            <h5 class="card-title"><?= $voo->getDestino() ?></h5>
            <p class="card-text">Origem: <?= $voo->getOrigem() ?></p>
            <p class="card-text">Origem: <?= $voo->getValor() ?></p>
            <a href="<?= BASE_URL ?>/view/viagem/comprar.php" class="btn btn-primary">Compre aqui</a>
        </div>
    </div>
    <?php endforeach; ?>
</div>



<?php
require_once(__DIR__ . "/include/footer.php");
?>