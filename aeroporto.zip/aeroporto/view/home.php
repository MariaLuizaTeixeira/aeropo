<?php

require_once(__DIR__ . "/include/header.php");
require_once(__DIR__ . "/include/menu.php");
require_once(__DIR__ . "/../controller/VooController.php");
require_once(__DIR__ . "/../util/config.php");

$vooController = new VooController();
$voosAleatorios = $vooController->listarAleatoriamente();

?>

<!-- TOPO -->
<div class="position-relative overflow-hidden">

    <!-- Imagem de fundo -->
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtTiQ_DY-ys9quVMZsnGukRr5EFmxT5pKcgjZiIpzCKQ&s=10"
         class="position-absolute w-100 h-100 object-fit-cover"
         style="filter: blur(5px); transform: scale(1.05);"
         alt="Viagem">

    <!-- Camada escura -->
    <div class="position-relative bg-dark bg-opacity-50 text-white py-5">

        <div class="container text-center py-5">

            <h1 class="display-3 fw-bold">
                Explore o mundo
            </h1>

            <p class="lead">
                Encontre seu próximo destino e embarque em uma nova aventura.
            </p>

            <a href="<?= BASE_URL ?>/view/voo/voos.php"
               class="btn btn-primary btn-lg mt-3">
                ✈️ Ver viagens
            </a>

        </div>

    </div>

</div>


<!-- DESTINOS -->
<div class="container my-5">

    <div class="text-center mb-4">

        <h2 class="fw-bold">
            Principais destinos
        </h2>

        <p class="text-muted">
            Confira alguns dos destinos disponíveis
        </p>

    </div>


    <div class="row g-4">

        <?php foreach($voosAleatorios as $voo): ?>

            <div class="col-md-6 col-lg-4">

                <div class="card h-100 shadow-sm">

                    <img
                        src="<?= $voo->getImagem() ?>"
                        class="card-img-top"
                        style="height: 200px; object-fit: cover;"
                        alt="<?= $voo->getDestino() ?>"
                    >

                    <div class="card-body d-flex flex-column">

                        <h4 class="card-title fw-bold">
                            <?= $voo->getDestino() ?>
                        </h4>

                        <p class="card-text text-muted mb-1">
                            📍 Origem: <?= $voo->getOrigem() ?>
                        </p>

                        <p class="card-text mt-2">
                            A partir de
                        </p>

                        <h4 class="text-primary fw-bold">
                            R$ <?= number_format($voo->getValor(), 2, ',', '.') ?>
                        </h4>

                        <a
                            href="<?= BASE_URL ?>/view/voo/comprar.php?id=<?= $voo->getId() ?>"
                            class="btn btn-primary mt-auto"
                        >
                            Comprar passagem
                        </a>

                    </div>

                </div>

            </div>

        <?php endforeach; ?>

    </div>

</div>


<?php
require_once(__DIR__ . "/include/footer.php");
?>