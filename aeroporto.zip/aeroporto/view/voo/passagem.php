<?php

require_once(__DIR__ . "/../include/header.php");
require_once(__DIR__ . "/../include/menu.php");
require_once(__DIR__ . "/../../controller/VooController.php");
require_once(__DIR__ . "/../../controller/PoltronaController.php");
require_once(__DIR__ . "/../../controller/ViagemController.php");
require_once(__DIR__  . "/../../model/Viagem.php");
require_once(__DIR__  . "/../../model/Cliente.php");

$vooController = new VooController();
$viagemController = new ViagemController();
$poltronaController = new PoltronaController();

$voo_id = $_GET['id'];

$voo = $vooController->buscarPorId($voo_id);

$poltronas = $poltronaController->listarDisponiveisPorVoo($voo_id);

$msgErro = "";
$viagem = new Viagem();
$viagem->setId(0);

if (isset($_POST['nome'])) {
    print("teste");
    $nome = trim($_POST['nome']) ? trim($_POST['nome']) : NULL;
    $email = trim($_POST['email']) ? trim($_POST['email']) : NULL;
    $cpf = trim($_POST['cpf']) ? trim($_POST['cpf']) : NULL;
    $poltrona_id = trim($_POST['poltrona']) ? (int)$_POST['poltrona'] : NULL;

    $cliente = new Cliente();
    $cliente->setCpf($cpf);
    $cliente->setNome($nome);
    $cliente->setEmail($email);
    $viagem->setCliente($cliente);

    $viagem->setVoo($voo);

    $poltrona = new Poltrona();
    $poltrona->setId(0);

    if ($poltrona_id) {
        $poltrona = $poltronaController->buscarPorId($poltrona_id);
    }

    $viagem->setPoltrona($poltrona);

    $erros = $viagemController->comprarPassagem($viagem);

    if (empty($erros))
        header("location: voos.php");
    else
        $msgErro = implode("<br>", $erros);
}

?>

<div class="container mt-5 mb-5">

    <div class="card shadow border-0">

        <div class="card-header bg-dark text-white text-center py-3">

            <h3 class="mb-0">
                ✈️ Comprar passagem
            </h3>

        </div>

        <div class="card-body p-4">

            <form action="" method="POST">

                <div class="row">

                    <div class="col-md-6 mb-3">

                        <label class="form-label fw-bold">
                            📍 Nome completo
                        </label>

                        <input
                            type="text"
                            name="nome"
                            class="form-control"
                            placeholder="Ex: João da Silva">

                    </div>

                    <div class="col-md-6 mb-3">

                        <label class="form-label fw-bold">
                            📍 Email
                        </label>

                        <input
                            type="text"
                            name="email"
                            class="form-control"
                            placeholder="Ex: joao.silva@email.com">

                    </div>

                </div>

                <div class="row">

                    <div class="col-md-6 mb-3">

                        <label class="form-label fw-bold">
                            CPF
                        </label>

                        <input
                            type="text"
                            name="cpf"
                            class="form-control"
                            placeholder="Ex: 123.456.789-00">

                    </div>

                </div>

                <div class="mb-3">

                    <label class="form-label fw-bold">
                        💺 Poltrona
                    </label>

                    <select name="poltrona" class="form-select">

                        <option value="">Selecione uma poltrona</option>

                        <?php foreach ($poltronas as $poltrona): ?>

                            <option value="<?= $poltrona->getId() ?>">
                                <?= $poltrona->getNumero() ?> - <?= $poltrona->getClasse() ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <button type="submit" class="btn btn-primary">
                    Comprar passagem
                </button>

            </form>

            <?php if (!empty($msgErro)): ?>

                <div class="alert alert-danger mt-3">
                    <?= $msgErro ?>
                </div>

            <?php endif; ?>

        </div>

    </div>

</div>

<?php
require_once(__DIR__ . "/../include/footer.php");
?>