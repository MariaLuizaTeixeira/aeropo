<?php

require_once(__DIR__ . "/../../controller/VooController.php");

$vooController = new VooController();

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $vooController->excluir($id);
    header("Location: voos.php");
    exit();
} else {
    echo "ID do voo não fornecido.";
}