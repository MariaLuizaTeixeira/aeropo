<?php

require_once(__DIR__ . "/../include/header.php");
require_once(__DIR__ . "/../include/menu.php");
require_once(__DIR__ . "/../../controller/VooController.php");

$vooController = new VooController();

$id = $_GET['id'];
$voo = $vooController->buscarPorId($id);

$msgErro = "";
$voo = NULL;

$vooCont = new VooController();

//Verificação se o usuário já clicou no gravar
if (isset($_POST['destino'])) {
    //Atualizar os dados do voo no banco de dados

    //1- Capturar os dados preenchidos no formulário
    $id = $_POST["id"];
    $destino = trim($_POST['destino']) ? trim($_POST['destino']) : NULL;
    $origem = trim($_POST['origem']) ? trim($_POST['origem']) : NULL;
    $saida = trim($_POST['saida']) ? trim($_POST['saida']) : NULL;
    $chegada = trim($_POST['chegada']) ? trim($_POST['chegada']) : NULL;
    $valor = trim($_POST['valor']) ? is_numeric($_POST['valor']) : NULL;
    $imagem = trim($_POST['imagem']) ? trim($_POST['imagem']) : NULL;

    //2- Criar um objeto Voo para persistí-lo
    $voo = new Voo();
    $voo->setId($id);
    $voo->setDestino($destino);
    $voo->setOrigem($origem);

    $saida = new DateTime($saida);
    $voo->setSaida($saida);

    $chegada = new DateTime($chegada);
    $voo->setChegada($chegada);
    $voo->setImagem($imagem);
    $voo->setValor($valor);

    //3- Validar os dados e salvar no banco
    $erros = $vooCont->alterar($voo);

    if (empty($erros))
        header("location: voos.php");
    else
        $msgErro = implode("<br>", $erros);
} else {
    //Carregar os dados do voo a ser alterado
    $id = 0;
    if (isset($_GET['id']))
        $id = $_GET['id'];

    $voo = $vooCont->buscarPorId($id);
    if (! $voo) {
        echo "ID do voo inválido!<br>";
        echo "<a href='voos.php'>Voltar</a>";
        exit;
    }
}

require_once(__DIR__ . "/form.php");

require_once(__DIR__ . "/../include/footer.php");
