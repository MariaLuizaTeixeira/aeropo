<?php

?>

<div class="container mt-5 mb-5">

    <div class="card shadow border-0">

        <div class="card-header bg-dark text-white text-center py-3">

            <h3 class="mb-0">
                ✈️ <?= $voo && $voo->getId() > 0 ? "Alterar voo" : "Inserir voo" ?>
            </h3>

        </div>

        <div class="card-body p-4">

            <form action="" method="POST">

                <input type="hidden" name="id" value="<?= $voo ? $voo->getId() : '' ?>">

                <div class="row">

                    <div class="col-md-6 mb-3">

                        <label class="form-label fw-bold">
                            📍 Destino
                        </label>

                        <input
                            type="text"
                            name="destino"
                            class="form-control"
                            placeholder="Ex: Rio de Janeiro"
                            value="<?= $voo->getDestino() ?>">

                    </div>

                    <div class="col-md-6 mb-3">

                        <label class="form-label fw-bold">
                            📍 Origem
                        </label>

                        <input
                            type="text"
                            name="origem"
                            class="form-control"
                            placeholder="Ex: São Paulo"
                            value="<?= $voo->getOrigem() ?>">

                    </div>

                </div>


                <div class="row">

                    <div class="col-md-6 mb-3">

                        <label class="form-label fw-bold">
                            🛫 Saída
                        </label>

                        <input
                            type="datetime-local"
                            name="saida"
                            class="form-control"
                            value="<?= $voo->getSaida() ? $voo->getSaida()->format('Y-m-d\TH:i') : '' ?>">

                    </div>

                    <div class="col-md-6 mb-3">

                        <label class="form-label fw-bold">
                            🛬 Chegada
                        </label>

                        <input
                            type="datetime-local"
                            name="chegada"
                            class="form-control"
                            value="<?= $voo->getChegada() ? $voo->getChegada()->format('Y-m-d\TH:i') : '' ?>">

                    </div>

                </div>


                <div class="mb-3">

                    <label class="form-label fw-bold">
                        🖼️ Imagem
                    </label>

                    <input
                        type="text"
                        name="imagem"
                        class="form-control"
                        placeholder="Cole a URL da imagem"
                        value="<?= $voo->getImagem() ?>">

                </div>


                <div class="mb-4">

                    <label class="form-label fw-bold">
                        💰 Valor da passagem
                    </label>

                    <div class="input-group">

                        <span class="input-group-text">
                            R$
                        </span>

                        <input
                            type="number"
                            step="0.01"
                            name="valor"
                            class="form-control"
                            placeholder="0,00"
                            value="<?= $voo->getValor() ?>">

                    </div>

                </div>


                <hr>


                <div class="d-flex justify-content-end gap-2 mt-4">

                    <a href="voos.php" class="btn btn-secondary">
                        ← Voltar
                    </a>

                    <button type="submit" class="btn btn-primary">
                        💾 Salvar voo
                    </button>

                </div>

            </form>

            <?php if (!empty($msgErro)): ?>

                <div class="alert alert-danger">
                    <?= $msgErro ?>
                </div>

            <?php endif; ?>

        </div>

    </div>

</div>