<?php

require_once(__DIR__ . "/../include/header.php");
require_once(__DIR__ . "/../include/menu.php");
require_once(__DIR__ . "/../../controller/VooController.php");

$msgErro = "";
$voo = new Voo();
$voo->setId(0);

//Verificação: formulário já foi submetido?
if (isset($_POST['destino'])) {
    //1- Capturar os dados preenchidos no formulário
    $destino = trim($_POST['destino']) ? trim($_POST['destino']) : NULL;
    $origem = trim($_POST['origem']) ? trim($_POST['origem']) : NULL;
    $saida = trim($_POST['saida']) ? trim($_POST['saida']) : NULL;
    $chegada = trim($_POST['chegada']) ? trim($_POST['chegada']) : NULL;
    $valor = trim($_POST['valor']) && is_numeric($_POST['valor'])
        ? (float)$_POST['valor']
        : NULL;
    $imagem = trim($_POST['imagem']) ? trim($_POST['imagem']) : NULL;

    //2- Criar um objeto Voo para persistí-lo
    $voo->setDestino($destino);
    $voo->setOrigem($origem);

    if ($saida) $voo->setSaida(new DateTime($saida));
    if ($chegada) $voo->setChegada(new DateTime($chegada));
    $voo->setImagem($imagem);
    $voo->setValor($valor);

    //3- Validar os dados
    //4- Persistir o objeto
    $vooCont = new VooController();
    $erros = $vooCont->inserir($voo);

    if (empty($erros))
        header("location: voos.php");
    else
        $msgErro = implode("<br>", $erros);
}

require_once(__DIR__ . "/form.php");
