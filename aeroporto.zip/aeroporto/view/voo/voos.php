<?php

require_once(__DIR__ . "/../include/header.php");
require_once(__DIR__ . "/../include/menu.php");
require_once(__DIR__ . "/../../controller/VooController.php");

$vooController = new VooController();
$voos = $vooController->listar();

?>

<div class="container mt-5 mb-5">

    <!-- Cabeçalho -->
    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>
            <h1 class="fw-bold mb-1">
                ✈️ Voos
            </h1>

            <p class="text-muted mb-0">
                Gerencie as viagens disponíveis.
            </p>
        </div>

        <a href="criar.php" class="btn btn-success">
            + Criar voo
        </a>

    </div>


    <!-- Tabela -->
    <div class="card shadow border-0">

        <div class="card-header bg-dark text-white py-3">
            <h5 class="mb-0">
                Lista de voos
            </h5>
        </div>

        <div class="table-responsive">

            <table class="table table-hover align-middle mb-0">

                <thead class="table-light">

                    <tr>
                        <th>Destino</th>
                        <th>Origem</th>
                        <th>Saída</th>
                        <th>Chegada</th>
                        <th>Valor</th>
                        <th>Imagem</th>
                        <th class="text-center">Ações</th>
                    </tr>

                </thead>

                <tbody>

                    <?php foreach ($voos as $voo): ?>

                        <tr>

                            <td>
                                <strong>
                                    <?= $voo->getDestino() ?>
                                </strong>
                            </td>

                            <td>
                                <?= $voo->getOrigem() ?>
                            </td>

                            <td>
                                <span class="badge text-bg-primary">
                                    <?= $voo->getSaida()->format('d/m/Y H:i') ?>
                                </span>
                            </td>

                            <td>
                                <span class="badge text-bg-secondary">
                                    <?= $voo->getChegada()->format('d/m/Y H:i') ?>
                                </span>
                            </td>

                            <td>
                                <strong class="text-success">
                                    R$ <?= number_format($voo->getValor(), 2, ',', '.') ?>
                                </strong>
                            </td>

                            <td>
                                <img
                                    src="<?= $voo->getImagem() ?>"
                                    width="100"
                                    height="60"
                                    class="rounded object-fit-cover"
                                    alt="Imagem do voo"
                                >
                            </td>

                            <td class="text-center">

                                <a
                                    href="editar.php?id=<?= $voo->getId() ?>"
                                    class="btn btn-warning btn-sm"
                                >
                                    ✏️ Editar
                                </a>

                                <a
                                    href="apagar.php?id=<?= $voo->getId() ?>"
                                    class="btn btn-danger btn-sm"
                                >
                                    🗑️ Apagar
                                </a>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>


<?php
require_once(__DIR__ . "/../include/footer.php");
?>