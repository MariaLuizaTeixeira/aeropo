<?php

require_once(__DIR__ . "/../include/header.php");
require_once(__DIR__ . "/../include/menu.php");
require_once(__DIR__ . "/../../controller/VooController.php");

$vooController = new VooController();
$voo = $vooController->buscarPorId($_GET['id']);

$saida = $voo->getSaida()->format('d/m/Y H:i');
$chegada = $voo->getChegada()->format('d/m/Y H:i');

?>

<div class="container my-5">

    <div class="card shadow-lg border-0 overflow-hidden">

        <!-- Imagem -->
        <img
            src="<?= $voo->getImagem() ?>"
            class="card-img-top"
            style="height: 350px; object-fit: cover;"
            alt="Imagem da viagem"
        >

        <div class="card-body p-4">

            <!-- Título -->
            <div class="text-center mb-4">

                <h1 class="fw-bold">
                    <?= $voo->getOrigem() ?>
                    <span class="text-primary">✈️</span>
                    <?= $voo->getDestino() ?>
                </h1>

                <p class="text-muted">
                    Detalhes da sua viagem
                </p>

            </div>

            <hr>

            <!-- Informações -->
            <div class="row mt-4">

                <div class="col-md-6">

                    <div class="card bg-light border-0 mb-3">
                        <div class="card-body">

                            <h6 class="text-muted">
                                📍 Origem
                            </h6>

                            <h5 class="fw-bold">
                                <?= $voo->getOrigem() ?>
                            </h5>

                        </div>
                    </div>

                </div>

                <div class="col-md-6">

                    <div class="card bg-light border-0 mb-3">
                        <div class="card-body">

                            <h6 class="text-muted">
                                📍 Destino
                            </h6>

                            <h5 class="fw-bold">
                                <?= $voo->getDestino() ?>
                            </h5>

                        </div>
                    </div>

                </div>

                <div class="col-md-6">

                    <div class="card bg-light border-0 mb-3">
                        <div class="card-body">

                            <h6 class="text-muted">
                                🛫 Saída
                            </h6>

                            <h5 class="fw-bold">
                                <?= $saida ?>
                            </h5>

                        </div>
                    </div>

                </div>

                <div class="col-md-6">

                    <div class="card bg-light border-0 mb-3">
                        <div class="card-body">

                            <h6 class="text-muted">
                                🛬 Chegada
                            </h6>

                            <h5 class="fw-bold">
                                <?= $chegada ?>
                            </h5>

                        </div>
                    </div>

                </div>

            </div>

            <!-- Preço -->
            <div class="text-center mt-4">

                <p class="text-muted mb-1">
                    Valor da passagem
                </p>

                <h2 class="text-primary fw-bold">
                    R$ <?= number_format($voo->getValor(), 2, ',', '.') ?>
                </h2>

            </div>

            <!-- Botões -->
            <div class="d-flex justify-content-center gap-2 mt-4">

                <a href="<?= BASE_URL ?>/view/home.php" class="btn btn-secondary">
                    ← Voltar
                </a>

                <a href="passagem.php?id=<?= $voo->getId() ?>"
                   class="btn btn-primary">
                    ✈️ Comprar passagem
                </a>

            </div>

        </div>

    </div>

</div>

<?php
require_once(__DIR__ . "/../include/footer.php");
?>