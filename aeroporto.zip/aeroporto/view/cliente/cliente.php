<?php

require_once(__DIR__ . "/include/header.php");
require_once(__DIR__ . "/include/menu.php");

?>
<div>
    <h1>teste</h1>
</div>

<?php
require_once(__DIR__ . "/include/footer.php");
?>