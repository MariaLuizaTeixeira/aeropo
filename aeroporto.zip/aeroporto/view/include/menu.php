 <?php
    require_once(__DIR__ . "/../../util/config.php");
 ?>
 
 <header>
     <div class="container">
         <h3>Viagens</h3>
     </div>

     <a href="<?= BASE_URL ?>/view/home.php"><button>Home</button></a>
     <a href="<?= BASE_URL ?>/view/cliente/cliente.php"><button>Página do usuário</button></a>
     <a href="<?= BASE_URL ?>/view/viagem/viagens.php"><button>Viagens disponíveis</button></a>

 </header>