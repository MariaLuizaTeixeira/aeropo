<?php
require_once(__DIR__ . "/../../util/config.php");
?>

<header>

    <nav class="navbar navbar-dark bg-dark">
        <div class="container">

            <a href="<?= BASE_URL ?>/view/home.php" class="navbar-brand">
                ✈️ Viagens
            </a>

            <div class="d-flex gap-2">

                <a href="<?= BASE_URL ?>/view/home.php" class="btn btn-outline-light">
                    Home
                </a>

                <a href="<?= BASE_URL ?>/view/voo/voos.php" class="btn btn-primary">
                    Viagens disponíveis
                </a>

            </div>

        </div>
    </nav>

</header>