<footer class="bg-dark text-white mt-5">

    <div class="container-fluid py-4">

        <div class="row px-4">

            <div class="col-md-6">
                <h5 class="fw-bold">✈️ Viagens</h5>

                <p class="text-secondary mb-0">
                    Encontre seu próximo destino e viaje pelo mundo.
                </p>
            </div>

            <div class="col-md-6 text-md-end mt-3 mt-md-0">
                <h6 class="fw-bold">Navegação</h6>

                <a href="<?= BASE_URL ?>/view/home.php"
                   class="text-secondary text-decoration-none me-3">
                    Home
                </a>

                <a href="<?= BASE_URL ?>/view/voo/voos.php"
                   class="text-secondary text-decoration-none">
                    Viagens
                </a>
            </div>

        </div>

        <hr class="border-secondary">

        <div class="text-center">
            <p class="text-secondary mb-0">
                © 2026 Viagens — Todos os direitos reservados.
            </p>
        </div>

    </div>

</footer>