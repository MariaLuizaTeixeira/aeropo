<?php

require_once(__DIR__ . "/../model/Voo.php");
require_once(__DIR__ . "/../util/Connection.php");

class VooDAO {
     public function list() {
        $sql = "SELECT * FROM voos";
        
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();
        
        $dados = $stm->fetchAll();
        return $this->map($dados);
    }

    public function listRandomly() {
        $sql = "SELECT * FROM voos ORDER BY RAND() LIMIT 10";
        
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();
        
        $dados = $stm->fetchAll();
        return $this->map($dados);
    }

    public function findById(int $id): ?Voo  {
        $sql = "SELECT * FROM voos WHERE id = ?";
        
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute([$id]);
        
        $dados = $stm->fetchAll();
        $voos = $this->map($dados);

        if(! empty($voos))
            return $voos[0];
        else
            return NULL;
    }

    public function insert(Voo $voo) {
        try {
            $sql = "INSERT INTO voos (destino, origem, saida, chegada, imagem, valor)
                    VALUES (:destino, :origem, :saida, :chegada, :imagem, :valor)";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("destino", $voo->getDestino());
            $stm->bindValue("origem", $voo->getOrigem());
            $stm->bindValue("saida", $voo->getSaida()->format('Y-m-d H:i:s'));
            $stm->bindValue("chegada", $voo->getChegada()->format('Y-m-d H:i:s'));
            $stm->bindValue("imagem", $voo->getImagem());
            $stm->bindValue("valor", $voo->getValor());
            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao salvar o voo. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }

    public function update(Voo $voo) {
        try {
            $sql = "UPDATE voos
                    SET destino = :destino, origem = :origem, saida = :saida, chegada = :chegada, imagem = :imagem, valor = :valor
                    WHERE id = :id";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("destino", $voo->getDestino());
            $stm->bindValue("origem", $voo->getOrigem());
            $stm->bindValue("saida", $voo->getSaida()->format('Y-m-d H:i:s'));
            $stm->bindValue("chegada", $voo->getChegada()->format('Y-m-d H:i:s'));
            $stm->bindValue("imagem", $voo->getImagem());
            $stm->bindValue("valor", $voo->getValor());
            $stm->bindValue("id", $voo->getId());

            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao salvar o voo. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }

    public function excluir(int $id) {
        try {
            $sql = "DELETE FROM voos WHERE id = ?";
            
            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->execute([$id]);
            return "";

        } catch(PDOException $e) {
            $erro = "Erro ao excluir o voo. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }

    private function map(array $dados) {
        $voos = array();
        foreach($dados as $d) {
            $voo = new Voo();
            $voo->setId($d['id']);
            $voo->setDestino($d["destino"]);
            $voo->setOrigem($d["origem"]);
            $voo->setSaida(new DateTime($d["saida"]));
            $voo->setChegada(new DateTime($d["chegada"]));
            $voo->setImagem($d["imagem"]);
            $voo->setValor($d["valor"]);

            array_push($voos, $voo);
        }
        return $voos;
    }
}

?>