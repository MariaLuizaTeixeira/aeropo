<?php

require_once(__DIR__ . "/../model/Viagem.php");
require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Cliente.php");
require_once(__DIR__ . "/../model/Viagem.php");
require_once(__DIR__ . "/../model/Voo.php");
require_once(__DIR__ . "/../model/Poltrona.php");

class ViagemDAO {
     public function list() {
        $sql = "SELECT * FROM viagens, c.nome, c.cpf, vo.destino, vo.origem, vo.saida, vo.chegada, p.numero, p.classe
                JOIN clientes c ON (c.id = viagens.cliente_id)
                JOIN voos vo ON (vo.id = viagens.voo_id)
                JOIN poltronas p ON (p.id = viagens.poltrona_id)";
        
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();
        
        $dados = $stm->fetchAll();
        return $this->map($dados);
    }

    public function findById(int $id): ?Viagem  {
        $sql = "SELECT * FROM viagens WHERE id = ?";
        
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute([$id]);
        
        $dados = $stm->fetchAll();
        $viagens = $this->map($dados);

        if(! empty($viagens))
            return $viagens[0];
        else
            return NULL;
    }

    public function insert(Viagem $viagem) {
        try {
            $sql = "INSERT INTO viagens (cliente_id, voo_id, poltrona_id)
                    VALUES (:cliente_id, :voo_id, :poltrona_id)";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("cliente_id", $viagem->getCliente()->getId());
            $stm->bindValue("voo_id", $viagem->getVoo()->getId());
            $stm->bindValue("poltrona_id", $viagem->getPoltrona()->getId());
            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao salvar a viagem. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }

    public function update(Viagem $viagem) {
        try {
            $sql = "UPDATE viagens
                    SET assento = :assento, cliente_id = :cliente_id, 
                    voo_id = :voo_id, poltrona_id = :poltrona_id
                    WHERE id = :id";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("cliente_id", $viagem->getCliente()->getId());
            $stm->bindValue("voo_id", $viagem->getVoo()->getId());
            $stm->bindValue("poltrona_id", $viagem->getPoltrona()->getId());
            $stm->bindValue("id", $viagem->getId());

            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao salvar a viagem. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }

    public function excluir(int $id) {
        try {
            $sql = "DELETE FROM viagens WHERE id = ?";
            
            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->execute([$id]);
            return "";

        } catch(PDOException $e) {
            $erro = "Erro ao excluir a viagem. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }

    private function map(array $dados) {
        $viagens = array();
        foreach($dados as $d) {
            $viagem = new Viagem();
            $viagem->setId($d['id']);

            $cliente = new CLiente();
            $cliente->setId($d["cliente_id"]);
            $viagem->setCliente($cliente);

            $poltrona = new Poltrona();
            $poltrona->setId($d["poltrona_id"]);
            $viagem->setPoltrona($poltrona);


            $voo = new Voo();
            $voo->setId($d["voo_id"]);
            $viagem->setVoo($voo);

            array_push($viagens, $viagem);
        }
        return $viagens;
    }
}

?>