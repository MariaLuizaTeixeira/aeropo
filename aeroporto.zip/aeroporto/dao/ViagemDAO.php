<?php

require_once(__DIR__ . "/../model/Viagem.php");
require_once(__DIR__ . "/../util/Connection.php");

class ViagemDAO {
     public function list() {
        $sql = "SELECT * FROM viagens, f.nome, c.nome, c.cpf, vo.destino, vo.origem, vo.saida, vo.chegada
                JOIN funcionarios f ON (f.id = viagens.funcionario_id)
                JOIN clientes c ON (c.id = viagens.cliente_id)
                JOIN voos vo ON (vo.id = viagens.voo_id)";
        
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();
        
        $dados = $stm->fetchAll();
        return $this->map($dados);
    }

    public function findById(int $id): ?Viagem  {
        $sql = "SELECT * FROM viagens WHERE id = ?";
        
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute([$id]);
        
        $dados = $stm->fetchAll();
        $viagens = $this->map($dados);

        if(! empty($viagens))
            return $viagens[0];
        else
            return NULL;
    }

    public function insert(Viagem $viagem) {
        try {
            $sql = "INSERT INTO viagens (assento, pago, cancelado, cliente_id, funcionario_id, voo_id)
                    VALUES (:assento, :pago, :cancelado, :cliente_id, :funcionario_id, :voo_id)";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("assento", $viagem->getAssento());
            $stm->bindValue("pago", $viagem->isPago());
            $stm->bindValue("cancelado", $viagem->isCancelado());
            $stm->bindValue("cliente_id", $viagem->getCliente()->getId());
            $stm->bindValue("funcionario_id", $viagem->getFuncionario()->getId());
            $stm->bindValue("voo_id", $viagem->getVoo()->getId());
            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao salvar a viagem. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }

    public function update(Viagem $viagem) {
        try {
            $sql = "UPDATE viagens
                    SET assento = :assento, pago = :pago, cancelado = :cancelado, cliente_id = :cliente_id, 
                    funcionario_id = :funcionario_id, voo_id = :voo_id
                    WHERE id = :id";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("assento", $viagem->getAssento());
            $stm->bindValue("pago", $viagem->isPago());
            $stm->bindValue("cancelado", $viagem->isCancelado());
            $stm->bindValue("cliente_id", $viagem->getCliente()->getId());
            $stm->bindValue("funcionario_id", $viagem->getFuncionario()->getId());
            $stm->bindValue("voo_id", $viagem->getVoo()->getId());
            $stm->bindValue("id", $viagem->getId());

            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao salvar a viagem. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }

    public function excluir(int $id) {
        try {
            $sql = "DELETE FROM viagens WHERE id = ?";
            
            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->execute([$id]);
            return "";

        } catch(PDOException $e) {
            $erro = "Erro ao excluir a viagem. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }

    private function map(array $dados) {
        $viagens = array();
        foreach($dados as $d) {
            $viagem = new Viagem();
            $viagem->setId($d['id']);
            $viagem->setAssento($d["assento"]);
            $viagem->setPago($d["pago"]);
            $viagem->setCancelado($d["cancelado"]);

            $cliente = new CLiente();
            $cliente->setId($d["cliente_id"]);
            $viagem->setCliente($cliente);

            $funcionario = new Funcionario();
            $funcionario->setId($d["funcionario_id"]);
            $viagem->setFuncionario($funcionario);


            $voo = new Voo();
            $voo->setId($d["voo_id"]);
            $viagem->setVoo($voo);

            array_push($viagens, $viagem);
        }
        return $viagens;
    }
}

?>