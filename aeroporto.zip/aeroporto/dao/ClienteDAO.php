<?php

require_once(__DIR__ . "/../model/Cliente.php");
require_once(__DIR__ . "/../util/Connection.php");

class ClienteDAO {
     public function list() {
        $sql = "SELECT * FROM clientes";
        
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();
        
        $dados = $stm->fetchAll();
        return $this->map($dados);
    }

    public function findById(int $id): ?Cliente  {
        $sql = "SELECT * FROM clientes WHERE id = ?";
        
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute([$id]);
        
        $dados = $stm->fetchAll();
        $clientes = $this->map($dados);

        if(! empty($clientes))
            return $clientes[0];
        else
            return NULL;
    }

    public function insert(Cliente $cliente) {
        try {
            $sql = "INSERT INTO clientes (nome, email, cpf)
                    VALUES (:nome, :email, :cpf)";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("nome", $cliente->getNome());
            $stm->bindValue("email", $cliente->getEmail());
            $stm->bindValue("cpf", $cliente->getCpf());
            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao salvar o cliente. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }

    public function update(Cliente $cliente) {
        try {
            $sql = "UPDATE clientes
                    SET nome = :nome, email = :email,
                    cpf = :cpf
                    WHERE id = :id";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("nome", $cliente->getNome());
            $stm->bindValue("email", $cliente->getEmail());
            $stm->bindValue("cpf", $cliente->getCpf());
            $stm->bindValue("id", $cliente->getId());

            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao salvar o cliente. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }

    public function excluir(int $id) {
        try {
            $sql = "DELETE FROM clientes WHERE id = ?";
            
            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->execute([$id]);
            return "";

        } catch(PDOException $e) {
            $erro = "Erro ao excluir o cliente. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }

    private function map(array $dados) {
        $clientes = array();
        foreach($dados as $d) {
            $cliente = new Cliente();
            $cliente->setId($d['id']);
            $cliente->setNome($d["nome"]);
            $cliente->setEmail($d["email"]);
            $cliente->setCpf($d["cpf"]);

            array_push($clientes, $cliente);
        }
        return $clientes;
    }
}

?>