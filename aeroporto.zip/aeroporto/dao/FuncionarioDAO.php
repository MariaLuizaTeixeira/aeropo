<?php

require_once(__DIR__ . "/../model/Funcionario.php");
require_once(__DIR__ . "/../util/Connection.php");

class FuncionarioDAO {
     public function list() {
        $sql = "SELECT * FROM funcionarios";
        
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();
        
        $dados = $stm->fetchAll();
        return $this->map($dados);
    }

    public function findById(int $id): ?Funcionario  {
        $sql = "SELECT * FROM funcionarios WHERE id = ?";
        
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute([$id]);
        
        $dados = $stm->fetchAll();
        $funcionarios = $this->map($dados);

        if(! empty($funcionarios))
            return $funcionarios[0];
        else
            return NULL;
    }

    public function insert(Funcionario $funcionario) {
        try {
            $sql = "INSERT INTO funcionarios (nome, email, cpf)
                    VALUES (:nome, :email, :cpf)";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("nome", $funcionario->getNome());
            $stm->bindValue("email", $funcionario->getEmail());
            $stm->bindValue("cpf", $funcionario->getCpf());
            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao salvar o funcionario. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }

    public function update(Funcionario $funcionario) {
        try {
            $sql = "UPDATE funcionarios
                    SET nome = :nome, email = :email,
                    cpf = :cpf
                    WHERE id = :id";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("nome", $funcionario->getNome());
            $stm->bindValue("email", $funcionario->getEmail());
            $stm->bindValue("cpf", $funcionario->getCpf());
            $stm->bindValue("id", $funcionario->getId());

            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao salvar o funcionario. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }

    public function excluir(int $id) {
        try {
            $sql = "DELETE FROM funcionarios WHERE id = ?";
            
            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->execute([$id]);
            return "";

        } catch(PDOException $e) {
            $erro = "Erro ao excluir o funcionario. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }

    private function map(array $dados) {
        $funcionarios = array();
        foreach($dados as $d) {
            $funcionario = new Funcionario();
            $funcionario->setId($d['id']);
            $funcionario->setNome($d["nome"]);
            $funcionario->setEmail($d["email"]);
            $funcionario->setCpf($d["cpf"]);

            array_push($funcionarios, $funcionario);
        }
        return $funcionarios;
    }
}

?>