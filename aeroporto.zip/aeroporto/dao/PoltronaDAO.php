<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Voo.php");
require_once(__DIR__ . "/../model/Poltrona.php");

class PoltronaDAO {

    public function listarDisponiveisPorVoo(Voo $voo): array {

        $sql = "SELECT *
                FROM poltronas
                WHERE id_voo = ?
                AND id NOT IN (
                    SELECT poltrona_id
                    FROM viagens
                    WHERE voo_id = ?
                )";

        $conn = Connection::getConnection();

        $stm = $conn->prepare($sql);

        $stm->execute([
            $voo->getId(),
            $voo->getId()
        ]);

        $dados = $stm->fetchAll();

        $poltronas = $this->map($dados);

        return $poltronas;
    }

    public function map(array $dados): array {

        $poltronas = [];

        foreach ($dados as $linha) {

            $poltrona = new Poltrona();

            $poltrona->setId($linha["id"]);

            $poltrona->setNumero($linha["numero"]);

            $poltrona->setClasse($linha["classe"]);

            $voo = new Voo();

            $voo->setId($linha["id_voo"]);

            $poltrona->setVoo($voo);

            array_push($poltronas, $poltrona);
        }

        return $poltronas;
    }

    public function findById(int $id): ?Poltrona {

        $sql = "SELECT *
                FROM poltronas
                WHERE id = ?";

        $conn = Connection::getConnection();

        $stm = $conn->prepare($sql);

        $stm->execute([$id]);

        $dados = $stm->fetchAll();

        if (count($dados) > 0) {
            $poltronas = $this->map($dados);
            return $poltronas[0];
        }

        return null;
    }
}
