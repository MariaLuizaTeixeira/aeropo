CREATE TABLE clientes (
    id        INTEGER      NOT NULL AUTO_INCREMENT,
    nome      VARCHAR(200) NOT NULL,
    email     VARCHAR(50)  NOT NULL,
    cpf       VARCHAR(11)  NOT NULL,

    CONSTRAINT pk_clientes PRIMARY KEY (id)
);

CREATE TABLE funcionarios (
    id        INTEGER      NOT NULL AUTO_INCREMENT,
    nome      VARCHAR(200) NOT NULL,
    email     VARCHAR(50)  NOT NULL,
    cpf       VARCHAR(11)  NOT NULL,

    CONSTRAINT pk_funcionario PRIMARY KEY (id)
);

CREATE TABLE voos (
    id           INTEGER      NOT NULL AUTO_INCREMENT,
    destino      VARCHAR(100) NOT NULL,
    origem       VARCHAR(100) NOT NULL,
    saida        DATETIME     NOT NULL,
    chegada      DATETIME     NOT NULL,
    imagem       TEXT NOT NULL,

    CONSTRAINT pk_voo PRIMARY KEY (id)
);

CREATE TABLE viagens (
    id                 INTEGER    NOT NULL AUTO_INCREMENT,
    assento            VARCHAR(3) NOT NULL,
    valor              FLOAT      NOT NULL,
    pago               BOOLEAN    NOT NULL,
    cancelado          BOOLEAN    NOT NULL,
    cliente_id         INTEGER    NOT NULL,
    funcionario_id     INTEGER    NOT NULL,
    voo_id             INTEGER    NOT NULL,

    CONSTRAINT pk_viagem      PRIMARY KEY (id),
    CONSTRAINT fk_cliente     FOREIGN KEY (cliente_id)     REFERENCES clientes (id),
    CONSTRAINT fk_funcionario FOREIGN KEY (funcionario_id) REFERENCES funcionarios (id),
    CONSTRAINT fk_voo         FOREIGN KEY (voo_id)         REFERENCES voos (id)
);

-- =========================================
-- CLIENTES
-- =========================================

INSERT INTO clientes (nome, email, cpf) VALUES
('João da Silva', 'joao.silva@email.com', '12345678901'),
('Maria Oliveira', 'maria.oliveira@email.com', '23456789012'),
('Carlos Santos', 'carlos.santos@email.com', '34567890123'),
('Ana Souza', 'ana.souza@email.com', '45678901234'),
('Pedro Costa', 'pedro.costa@email.com', '56789012345');


-- =========================================
-- FUNCIONÁRIOS
-- =========================================

INSERT INTO funcionarios (nome, email, cpf) VALUES
('Roberto Almeida', 'roberto.almeida@empresa.com', '11122233344'),
('Juliana Martins', 'juliana.martins@empresa.com', '22233344455'),
('Fernanda Lima', 'fernanda.lima@empresa.com', '33344455566'),
('Marcos Pereira', 'marcos.pereira@empresa.com', '44455566677'),
('Camila Rodrigues', 'camila.rodrigues@empresa.com', '55566677788');


-- =========================================
-- VOOS
-- =========================================

INSERT INTO voos (destino, origem, saida, chegada, imagem) VALUES

('Rio de Janeiro', 'São Paulo', '2026-10-05 08:00:00', '2026-10-05 09:05:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQX8No62CFmMC9jbljQ4P3cqjJWYCOnIs1ucCt3PwIT3w&s=10'),

('Salvador', 'Brasília', '2026-10-07 10:30:00', '2026-10-07 12:40:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSedjk2Dcm9v-otzAl9IAIgHyRoopv6ssI0IolX8XGEHA&s=10'),

('Recife', 'São Paulo', '2026-10-10 14:00:00', '2026-10-10 17:05:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTc9c_gWm2R6QnuQ_OZWTdHnlmUIO27w5e5Fzj9xar6LA&s=10'),

('Florianópolis', 'Curitiba', '2026-10-15 09:15:00', '2026-10-15 10:20:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQWx_YGWif4WRDGDUy5BaPREFrCZdAfxARmH5p6DcAm6A&s=10'),

('Porto Alegre', 'São Paulo', '2026-10-18 16:00:00', '2026-10-18 17:50:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQk0L4K9fVgH93mPi8IVtuCs6IBuPCMCi0GJZFoiMNKTA&s=10'),

('Buenos Aires', 'São Paulo', '2026-11-02 09:00:00', '2026-11-02 11:55:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQTrgeZ3MgkIHvsCyAZP83G5Kuz44RDfxBb1DzluNP9Ig&s=10'),

('Santiago', 'Rio de Janeiro', '2026-11-05 22:00:00', '2026-11-06 02:10:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTxWXNWPE0QUF778zSzrjoUcVfsnTUUIusiKeMovyb84g&s=10'),

('Lima', 'São Paulo', '2026-11-08 08:30:00', '2026-11-08 13:00:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPueqI0hbcCQhVAJh_fjKk6ASRwJO5SexHlKxnqrlYCg&s=10'),

('Nova York', 'São Paulo', '2026-11-12 21:30:00', '2026-11-13 05:45:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTDZDBTzTLe4AlI3kWbxQNQuxrllVP_tKSlyucZ7J5RHQ&s=10'),

('Toronto', 'São Paulo', '2026-11-15 20:30:00', '2026-11-16 06:15:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTUQU6zhxBuN0yIvbvV4aCMSiJAMsHfjgmy2mSg9QKYbA&s=10'),

('Cidade do México', 'Brasília', '2026-11-18 09:00:00', '2026-11-18 15:30:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ0REVDIJhdatDyWdLId0ZhDdzGfIaO6YznvngEBsY5tg&s=10'),

('Lisboa', 'São Paulo', '2026-11-22 18:30:00', '2026-11-23 06:45:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbSfeWz2y-V0i-RqNgQ4O-FYdCVUHdJdhzcI0TIfP64g&s=10'),

('Paris', 'Rio de Janeiro', '2026-11-25 20:00:00', '2026-11-26 10:50:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPMDDK1BX_jKbra9wFsdY-d_MVNa7qrdH0i4enN_7fUg&s=10'),

('Roma', 'São Paulo', '2026-11-28 19:45:00', '2026-11-29 11:20:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQdYuh3LDqpnV8deiPoYIyOv9S33i9QOJ8g9jRmq24dCA&s=10'),

('Tóquio', 'São Paulo', '2026-12-02 22:15:00', '2026-12-04 06:30:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQXPvOcyXzspzVUj23H-sIJ2Kb2OjS_wK14jwey76HDWw&s=10'),

('Dubai', 'Rio de Janeiro', '2026-12-05 21:00:00', '2026-12-06 18:40:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkZgeLQA8Gr7tnx4skv3-YkXlog9zIgeKtXZqWbwBqfA&s=10'),

('Bangkok', 'São Paulo', '2026-12-08 20:00:00', '2026-12-10 08:30:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSlx0RzvAKdYZbp487t4BnSQWXl27afIBVintL4SlKrDQ&s=10'),

('Cairo', 'São Paulo', '2026-12-12 18:00:00', '2026-12-13 14:30:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPeJGBfsMh4W7i6AVVymTut6aEmU7jchK_VXbfQMUjow&s=10'),

('Cidade do Cabo', 'São Paulo', '2026-12-15 19:30:00', '2026-12-16 09:45:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJa5zmlbFLTuaWF5Bgtsyo4L6Agso0feEwjEwrdamT_A&s=10'),

('Sydney', 'São Paulo', '2026-12-20 22:00:00', '2026-12-22 06:30:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQYk_6PPn8cWJtpZlAH_BtqIXDv5CZifPrkd5_h47Zmxg&s=10');




-- =========================================
-- VIAGENS
-- =========================================

INSERT INTO viagens
(assento, valor, pago, cancelado, cliente_id, funcionario_id, voo_id)
VALUES
('1A', 450.00, TRUE, FALSE, 1, 1, 1),
('2B', 620.50, TRUE, FALSE, 2, 2, 2),
('3C', 780.00, FALSE, FALSE, 3, 3, 3),
('4D', 550.75, TRUE, FALSE, 4, 4, 4),
('5E', 390.00, FALSE, TRUE, 5, 5, 5);


