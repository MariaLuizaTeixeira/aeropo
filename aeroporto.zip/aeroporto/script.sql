CREATE TABLE clientes (
    id        INTEGER      NOT NULL AUTO_INCREMENT,
    nome      VARCHAR(200) NOT NULL,
    email     VARCHAR(50)  NOT NULL,
    cpf       VARCHAR(11)  NOT NULL,

    CONSTRAINT pk_clientes PRIMARY KEY (id)
);

CREATE TABLE voos (
    id           INTEGER      NOT NULL AUTO_INCREMENT,
    destino      VARCHAR(100) NOT NULL,
    origem       VARCHAR(100) NOT NULL,
    saida        DATETIME     NOT NULL,
    chegada      DATETIME     NOT NULL,
    valor        FLOAT        NOT NULL,
    imagem       TEXT NOT NULL,

    CONSTRAINT pk_voo PRIMARY KEY (id)
);

CREATE TABLE poltronas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero VARCHAR(5) NOT NULL,
    classe VARCHAR(20) NOT NULL,
    id_voo INT NOT NULL,

    FOREIGN KEY (id_voo) REFERENCES voos(id)
);

CREATE TABLE viagens (
    id                 INTEGER    NOT NULL AUTO_INCREMENT,
    cliente_id         INTEGER    NOT NULL,
    voo_id             INTEGER    NOT NULL,
    poltrona_id        INTEGER NOT NULL,

    CONSTRAINT pk_viagem      PRIMARY KEY (id),
    CONSTRAINT fk_cliente     FOREIGN KEY (cliente_id)     REFERENCES clientes (id),
    CONSTRAINT fk_voo         FOREIGN KEY (voo_id)         REFERENCES voos (id),
    CONSTRAINT fk_poltrona    FOREIGN KEY (poltrona_id)    REFERENCES poltronas (id)
);



-- =========================================
-- CLIENTES
-- =========================================

INSERT INTO clientes (nome, email, cpf) VALUES
('João da Silva', 'joao@gmail.com', '12345678901'),
('Maria Oliveira', 'maria@gmail.com', '23456789012'),
('Carlos Santos', 'carlos@gmail.com', '34567890123'),
('Ana Souza', 'ana@gmail.com', '45678901234'),
('Pedro Costa', 'pedro@gmail.com', '56789012345');


-- =========================================
-- VOOS
-- =========================================

INSERT INTO voos (destino, origem, saida, chegada, imagem, valor) VALUES

('Rio de Janeiro', 'São Paulo', '2026-10-05 08:00:00', '2026-10-05 09:05:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQX8No62CFmMC9jbljQ4P3cqjJWYCOnIs1ucCt3PwIT3w&s=10', 450.00),

('Salvador', 'Brasília', '2026-10-07 10:30:00', '2026-10-07 12:40:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSedjk2Dcm9v-otzAl9IAIgHyRoopv6ssI0IolX8XGEHA&s=10', 620.00),

('Recife', 'São Paulo', '2026-10-10 14:00:00', '2026-10-10 17:05:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTc9c_gWm2R6QnuQ_OZWTdHnlmUIO27w5e5Fzj9xar6LA&s=10', 580.00),

('Florianópolis', 'Curitiba', '2026-10-15 09:15:00', '2026-10-15 10:20:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQWx_YGWif4WRDGDUy5BaPREFrCZdAfxARmH5p6DcAm6A&s=10', 320.00),

('Porto Alegre', 'São Paulo', '2026-10-18 16:00:00', '2026-10-18 17:50:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQk0L4K9fVgH93mPi8IVtuCs6IBuPCMCi0GJZFoiMNKTA&s=10', 490.00),

('Buenos Aires', 'São Paulo', '2026-11-02 09:00:00', '2026-11-02 11:55:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQTrgeZ3MgkIHvsCyAZP83G5Kuz44RDfxBb1DzluNP9Ig&s=10', 1100.00),

('Santiago', 'Rio de Janeiro', '2026-11-05 22:00:00', '2026-11-06 02:10:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTxWXNWPE0QUF778zSzrjoUcVfsnTUUIusiKeMovyb84g&s=10', 1350.00),

('Lima', 'São Paulo', '2026-11-08 08:30:00', '2026-11-08 13:00:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPueqI0hbcCQhVAJh_fjKk6ASRwJO5SexHlKxnqrlYCg&s=10', 1450.00),

('Nova York', 'São Paulo', '2026-11-12 21:30:00', '2026-11-13 05:45:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTDZDBTzTLe4AlI3kWbxQNQuxrllVP_tKSlyucZ7J5RHQ&s=10', 3200.00),

('Toronto', 'São Paulo', '2026-11-15 20:30:00', '2026-11-16 06:15:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTUQU6zhxBuN0yIvbvV4aCMSiJAMsHfjgmy2mSg9QKYbA&s=10', 3500.00),

('Cidade do México', 'Brasília', '2026-11-18 09:00:00', '2026-11-18 15:30:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ0REVDIJhdatDyWdLId0ZhDdzGfIaO6YznvngEBsY5tg&s=10', 2800.00),

('Lisboa', 'São Paulo', '2026-11-22 18:30:00', '2026-11-23 06:45:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbSfeWz2y-V0i-RqNgQ4O-FYdCVUHdJdhzcI0TIfP64g&s=10', 4200.00),

('Paris', 'Rio de Janeiro', '2026-11-25 20:00:00', '2026-11-26 10:50:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPMDDK1BX_jKbra9wFsdY-d_MVNa7qrdH0i4enN_7fUg&s=10', 4500.00),

('Roma', 'São Paulo', '2026-11-28 19:45:00', '2026-11-29 11:20:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQdYuh3LDqpnV8deiPoYIyOv9S33i9QOJ8g9jRmq24dCA&s=10', 4700.00),

('Tóquio', 'São Paulo', '2026-12-02 22:15:00', '2026-12-04 06:30:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQXPvOcyXzspzVUj23H-sIJ2Kb2OjS_wK14jwey76HDWw&s=10', 6500.00),

('Dubai', 'Rio de Janeiro', '2026-12-05 21:00:00', '2026-12-06 18:40:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkZgeLQA8Gr7tnx4skv3-YkXlog9zIgeKtXZqWbwBqfA&s=10', 6800.00),

('Bangkok', 'São Paulo', '2026-12-08 20:00:00', '2026-12-10 08:30:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSlx0RzvAKdYZbp487t4BnSQWXl27afIBVintL4SlKrDQ&s=10', 7200.00),

('Cairo', 'São Paulo', '2026-12-12 18:00:00', '2026-12-13 14:30:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPeJGBfsMh4W7i6AVVymTut6aEmU7jchK_VXbfQMUjow&s=10', 5900.00),

('Cidade do Cabo', 'São Paulo', '2026-12-15 19:30:00', '2026-12-16 09:45:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJa5zmlbFLTuaWF5Bgtsyo4L6Agso0feEwjEwrdamT_A&s=10', 6100.00),

('Sydney', 'São Paulo', '2026-12-20 22:00:00', '2026-12-22 06:30:00',
 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQYk_6PPn8cWJtpZlAH_BtqIXDv5CZifPrkd5_h47Zmxg&s=10', 7500.00);

INSERT INTO poltronas (numero, classe, id_voo) VALUES
('01A', 'Economica', 1),
('01B', 'Economica', 1),
('02A', 'Economica', 1),
('02B', 'Economica', 1),
('03A', 'Economica', 1),
('03B', 'Economica', 1),
('04A', 'Executiva', 1),
('04B', 'Executiva', 1),
('05A', 'Executiva', 1),
('05B', 'Executiva', 1),

('01A', 'Economica', 2),
('01B', 'Economica', 2),
('02A', 'Economica', 2),
('02B', 'Economica', 2),
('03A', 'Economica', 2),
('03B', 'Economica', 2),
('04A', 'Executiva', 2),
('04B', 'Executiva', 2),
('05A', 'Executiva', 2),
('05B', 'Executiva', 2),

('01A', 'Economica', 3),
('01B', 'Economica', 3),
('02A', 'Economica', 3),
('02B', 'Economica', 3),
('03A', 'Economica', 3),
('03B', 'Economica', 3),
('04A', 'Executiva', 3),
('04B', 'Executiva', 3),
('05A', 'Executiva', 3),
('05B', 'Executiva', 3),

('01A', 'Economica', 4),
('01B', 'Economica', 4),
('02A', 'Economica', 4),
('02B', 'Economica', 4),
('03A', 'Economica', 4),
('03B', 'Economica', 4),
('04A', 'Executiva', 4),
('04B', 'Executiva', 4),
('05A', 'Executiva', 4),
('05B', 'Executiva', 4),

('01A', 'Economica', 5),
('01B', 'Economica', 5),
('02A', 'Economica', 5),
('02B', 'Economica', 5),
('03A', 'Economica', 5),
('03B', 'Economica', 5),
('04A', 'Executiva', 5),
('04B', 'Executiva', 5),
('05A', 'Executiva', 5),
('05B', 'Executiva', 5);


-- =========================================
-- VIAGENS
-- =========================================

INSERT INTO viagens
(cliente_id, voo_id, poltrona_id)
VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3),
(4, 4, 4),
(5, 5, 5);
INSERT INTO poltronas (numero, classe, id_voo) VALUES
('01A', 'Economica', 6),
('01B', 'Economica', 6),
('02A', 'Economica', 6),
('02B', 'Economica', 6),
('03A', 'Economica', 6),
('03B', 'Economica', 6),
('04A', 'Executiva', 6),
('04B', 'Executiva', 6),
('05A', 'Executiva', 6),
('05B', 'Executiva', 6),

('01A', 'Economica', 7),
('01B', 'Economica', 7),
('02A', 'Economica', 7),
('02B', 'Economica', 7),
('03A', 'Economica', 7),
('03B', 'Economica', 7),
('04A', 'Executiva', 7),
('04B', 'Executiva', 7),
('05A', 'Executiva', 7),
('05B', 'Executiva', 7),

('01A', 'Economica', 8),
('01B', 'Economica', 8),
('02A', 'Economica', 8),
('02B', 'Economica', 8),
('03A', 'Economica', 8),
('03B', 'Economica', 8),
('04A', 'Executiva', 8),
('04B', 'Executiva', 8),
('05A', 'Executiva', 8),
('05B', 'Executiva', 8),

('01A', 'Economica', 9),
('01B', 'Economica', 9),
('02A', 'Economica', 9),
('02B', 'Economica', 9),
('03A', 'Economica', 9),
('03B', 'Economica', 9),
('04A', 'Executiva', 9),
('04B', 'Executiva', 9),
('05A', 'Executiva', 9),
('05B', 'Executiva', 9);
-- Voo 10 - Toronto
('01A', 'Economica', 10),
('01B', 'Economica', 10),
('02A', 'Economica', 10),
('02B', 'Economica', 10),
('03A', 'Economica', 10),
('03B', 'Economica', 10),
('04A', 'Executiva', 10),
('04B', 'Executiva', 10),
('05A', 'Executiva', 10),
('05B', 'Executiva', 10),

-- Voo 11 - Cidade do México
('01A', 'Economica', 11),
('01B', 'Economica', 11),
('02A', 'Economica', 11),
('02B', 'Economica', 11),
('03A', 'Economica', 11),
('03B', 'Economica', 11),
('04A', 'Executiva', 11),
('04B', 'Executiva', 11),
('05A', 'Executiva', 11),
('05B', 'Executiva', 11),

-- Voo 12 - Lisboa
('01A', 'Economica', 12),
('01B', 'Economica', 12),
('02A', 'Economica', 12),
('02B', 'Economica', 12),
('03A', 'Economica', 12),
('03B', 'Economica', 12),
('04A', 'Executiva', 12),
('04B', 'Executiva', 12),
('05A', 'Executiva', 12),
('05B', 'Executiva', 12),

-- Voo 13 - Paris
('01A', 'Economica', 13),
('01B', 'Economica', 13),
('02A', 'Economica', 13),
('02B', 'Economica', 13),
('03A', 'Economica', 13),
('03B', 'Economica', 13),
('04A', 'Executiva', 13),
('04B', 'Executiva', 13),
('05A', 'Executiva', 13),
('05B', 'Executiva', 13),

-- Voo 14 - Roma
('01A', 'Economica', 14),
('01B', 'Economica', 14),
('02A', 'Economica', 14),
('02B', 'Economica', 14),
('03A', 'Economica', 14),
('03B', 'Economica', 14),
('04A', 'Executiva', 14),
('04B', 'Executiva', 14),
('05A', 'Executiva', 14),
('05B', 'Executiva', 14),

-- Voo 15 - Tóquio
('01A', 'Economica', 15),
('01B', 'Economica', 15),
('02A', 'Economica', 15),
('02B', 'Economica', 15),
('03A', 'Economica', 15),
('03B', 'Economica', 15),
('04A', 'Executiva', 15),
('04B', 'Executiva', 15),
('05A', 'Executiva', 15),
('05B', 'Executiva', 15),

-- Voo 16 - Dubai
('01A', 'Economica', 16),
('01B', 'Economica', 16),
('02A', 'Economica', 16),
('02B', 'Economica', 16),
('03A', 'Economica', 16),
('03B', 'Economica', 16),
('04A', 'Executiva', 16),
('04B', 'Executiva', 16),
('05A', 'Executiva', 16),
('05B', 'Executiva', 16),

-- Voo 17 - Bangkok
('01A', 'Economica', 17),
('01B', 'Economica', 17),
('02A', 'Economica', 17),
('02B', 'Economica', 17),
('03A', 'Economica', 17),
('03B', 'Economica', 17),
('04A', 'Executiva', 17),
('04B', 'Executiva', 17),
('05A', 'Executiva', 17),
('05B', 'Executiva', 17),

-- Voo 18 - Cairo
('01A', 'Economica', 18),
('01B', 'Economica', 18),
('02A', 'Economica', 18),
('02B', 'Economica', 18),
('03A', 'Economica', 18),
('03B', 'Economica', 18),
('04A', 'Executiva', 18),
('04B', 'Executiva', 18),
('05A', 'Executiva', 18),
('05B', 'Executiva', 18),

-- Voo 19 - Cidade do Cabo
('01A', 'Economica', 19),
('01B', 'Economica', 19),
('02A', 'Economica', 19),
('02B', 'Economica', 19),
('03A', 'Economica', 19),
('03B', 'Economica', 19),
('04A', 'Executiva', 19),
('04B', 'Executiva', 19),
('05A', 'Executiva', 19),
('05B', 'Executiva', 19),

-- Voo 20 - Sydney
('01A', 'Economica', 20),
('01B', 'Economica', 20),
('02A', 'Economica', 20),
('02B', 'Economica', 20),
('03A', 'Economica', 20),
('03B', 'Economica', 20),
('04A', 'Executiva', 20),
('04B', 'Executiva', 20),
('05A', 'Executiva', 20),
('05B', 'Executiva', 20);
INSERT INTO poltronas (numero, classe, id_voo) VALUES

