<?php

require_once(__DIR__ . "/../model/Voo.php");

class VooService {
    public function validar(Voo $voo) {
        $erros = array();

        if (!$voo->getDestino()) array_push($erros, "Informe o destino!");
        if (!$voo->getOrigem()) array_push($erros, "Informe a origem!");
        if (!$voo->getSaida()) array_push($erros, "Informe o horário de saída!");
        if (!$voo->getChegada()) array_push($erros, "Informe o horário de chegada!");
        if (!$voo->getImagem()) array_push($erros, "Informe a imagem!");
        if (!$voo->getValor()) array_push($erros, "Informe o valor!");

        return $erros;
    }
}
