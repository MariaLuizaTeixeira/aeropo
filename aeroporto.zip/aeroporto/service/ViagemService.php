<?php

require_once(__DIR__ . "/../model/Viagem.php");

class ViagemService {
    public function validar(Viagem $viagem) {
        $erros = array();

        if(!$viagem->getAssento())array_push($erros, "Informe o assento!");

        if(!$viagem->isPago()) array_push($erros, "Informe se está pago ou não!");

        if(!$viagem->isCancelado()) array_push($erros, "Informe se está cancelado ou não!");

        if(!$viagem->getCliente()->getId()) array_push($erros, "Informe o cliente!");

        if(!$viagem->getFuncionario()->getId()) array_push($erros, "Informe o funcionário!");

        if(!$viagem->getVoo()->getId()) array_push($erros, "Informe o voô!");
        
        return $erros;
    }

}