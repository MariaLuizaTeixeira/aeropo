<?php

require_once(__DIR__ . "/../model/Viagem.php");
require_once(__DIR__ . "/../util/ValidarCPF.php");

class ViagemService {

    private ValidarCPF $validarCPF;

    public function __construct() {
        $this->validarCPF = new ValidarCPF();
    }
    
    public function validar(Viagem $viagem) {
        $erros = array();

        if(!$viagem->getCliente()->getNome()) array_push($erros, "Informe o cliente!");
        if(!$viagem->getCliente()->getEmail()) array_push($erros, "Informe o email!");
        if(!$viagem->getCliente()->getCpf()) array_push($erros, "Informe o CPF!");
        if(!$this->validarCPF->validar($viagem->getCliente()->getCpf())) array_push($erros, "CPF inválido!");
        if(!$viagem->getPoltrona()->getId()) array_push($erros, "Informe a poltrona!");
        if(!$viagem->getVoo()->getId()) array_push($erros, "Informe o voô!");
        
        return $erros;
    }

}