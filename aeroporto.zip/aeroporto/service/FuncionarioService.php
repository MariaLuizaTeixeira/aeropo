<?php

require_once(__DIR__ . "/../model/Funcionario.php");
require_once(__DIR__ . "/../util/ValidarCPF.php");

class FuncionarioService {

    private ValidarCPF $validarCPF;

    public function __construct()
    {
        $this->validarCPF = new ValidarCPF();
    }

    public function validar(Funcionario $funcionario) {
        $erros = array();

        if(!$funcionario->getNome())array_push($erros, "Informe o nome!");

        $nomeCompleto = explode(" ", $funcionario->getNome());
        if(strlen($nomeCompleto[0]) < 2 || strlen($nomeCompleto[1]) < 2)array_push($erros, "Informe o nome completo!");
        
        if(!$funcionario->getEmail()) array_push($erros, "Informe o email!");
        if(filter_var($funcionario->getEmail(), FILTER_VALIDATE_EMAIL)) array_push($erros, "Informe um email válido!");

        if(! $funcionario->getCpf()) array_push($erros, "Informe o CPF!");
        if($this->validarCPF->validar($funcionario->getCpf())) array_push($erros, "Informe um CPF válido!");
        
        return $erros;
    }

}