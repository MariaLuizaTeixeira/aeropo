<?php

require_once(__DIR__ . "/../model/Cliente.php");
require_once(__DIR__ . "/../util/ValidarCPF.php");

class ClienteService {

    private ValidarCPF $validarCPF;

    public function __construct()
    {
        $this->validarCPF = new ValidarCPF();
    }

    public function validar(Cliente $cliente) {
        $erros = array();

        if(!$cliente->getNome())array_push($erros, "Informe o nome!");

        $nomeCompleto = explode(" ", $cliente->getNome());
        if(strlen($nomeCompleto[0]) < 2 || strlen($nomeCompleto[1]) < 2)array_push($erros, "Informe o nome completo!");
        
        if(!$cliente->getEmail()) array_push($erros, "Informe o email!");
        if(filter_var($cliente->getEmail(), FILTER_VALIDATE_EMAIL)) array_push($erros, "Informe um email válido!");

        if(! $cliente->getCpf()) array_push($erros, "Informe o CPF!");
        if($this->validarCPF->validar($cliente->getCpf())) array_push($erros, "Informe um CPF válido!");
        
        return $erros;
    }

}