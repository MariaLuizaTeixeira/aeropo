<?php

require_once(__DIR__ . "/../dao/FuncionarioDAO.php");
require_once(__DIR__ . "/../service/FuncionarioService.php");

class FuncionarioController {
    private FuncionarioDAO $funcionarioDAO;
    private FuncionarioService $funcionarioService;

    public function __construct() {
        $this->funcionarioDAO = new FuncionarioDAO();
        $this->funcionarioService = new FuncionarioService();
    }

    public function listar() {
        return $this->funcionarioDAO->list();
    }

    public function buscarPorId(int $id) {
        return $this->funcionarioDAO->findById($id);
    }

    public function inserir($funcionario) {
        //Validar os dados
        $erros = $this->funcionarioService->validar($funcionario);


        //Persistir os dados
        if(empty($erros)) {
            $erroDAO = $this->funcionarioDAO->insert($funcionario);
            if($erroDAO) array_push($erros, $erroDAO); 
        }

        return $erros;
    }

    public function alterar($funcionario) {
        //Validar os dados
        $erros = $this->funcionarioService->validar($funcionario);

        //Persistir os dados
        if(empty($erros)) {
            $erroDAO = $this->funcionarioDAO->update($funcionario);
            if($erroDAO)
               array_push($erros, $erroDAO); 
        }

        return $erros;
    }

    public function excluir(int $id) {
        return $this->funcionarioDAO->excluir($id);
    }
}

?>