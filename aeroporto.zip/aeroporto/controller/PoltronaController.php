<?php

require_once(__DIR__ . "/../dao/PoltronaDAO.php");
require_once(__DIR__ . "/VooController.php");

class PoltronaController {

    private PoltronaDAO $poltronaDAO;

    private VooController $vooController;

    public function __construct() {

        $this->poltronaDAO = new PoltronaDAO();

        $this->vooController = new VooController();
    }

    public function listarDisponiveisPorVoo(int $idVoo) {

        $voo = $this->vooController->buscarPorId($idVoo);

        return $this->poltronaDAO->listarDisponiveisPorVoo($voo);
    }

    public function buscarPorId(int $id): ?Poltrona {

        return $this->poltronaDAO->findById($id);
    }
}
