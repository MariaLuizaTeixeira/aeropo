<?php

require_once(__DIR__ . "/../dao/ViagemDAO.php");
require_once(__DIR__ . "/../service/ViagemService.php");

class ViagemController {
    private ViagemDAO $viagemDAO;
    private ViagemService $viagemService;

    public function __construct() {
        $this->viagemDAO = new ViagemDAO();
        $this->viagemService = new ViagemService();
    }

    public function listar() {
        return $this->viagemDAO->list();
    }

    public function buscarPorId(int $id) {
        return $this->viagemDAO->findById($id);
    }

    public function inserir($viagem) {
        //Validar os dados
        $erros = $this->viagemService->validar($viagem);


        //Persistir os dados
        if(empty($erros)) {
            $erroDAO = $this->viagemDAO->insert($viagem);
            if($erroDAO)
               array_push($erros, $erroDAO); 
        }

        return $erros;
    }

    public function alterar($viagem) {
        //Validar os dados
        $erros = $this->viagemService->validar($viagem);

        //Persistir os dados
        if(empty($erros)) {
            $erroDAO = $this->viagemDAO->update($viagem);
            if($erroDAO)
               array_push($erros, $erroDAO); 
        }

        return $erros;
    }

    public function excluir(int $id) {
        return $this->viagemDAO->excluir($id);
    }
}

?>