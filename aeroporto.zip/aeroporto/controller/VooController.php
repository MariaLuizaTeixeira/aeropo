<?php

require_once(__DIR__ . "/../dao/VooDAO.php");
require_once(__DIR__ . "/../service/VooService.php");

class VooController {
    private VooDAO $vooDAO;
    private VooService $vooService;

    public function __construct() {
        $this->vooDAO = new VooDAO();
        $this->vooService = new VooService();
    }

    public function listar() {
        return $this->vooDAO->list();
    }

    public function listarAleatoriamente() {
        return $this->vooDAO->listRandomly();
    }

    public function buscarPorId(int $id) {
        return $this->vooDAO->findById($id);
    }

    public function inserir($voo) {
        //Validar os dados
        $erros = $this->vooService->validar($voo);


        //Persistir os dados
        if(empty($erros)) {
            $erroDAO = $this->vooDAO->insert($voo);
            if($erroDAO)
               array_push($erros, $erroDAO); 
        }

        return $erros;
    }

    public function alterar($voo) {
        //Validar os dados
        $erros = $this->vooService->validar($voo);

        //Persistir os dados
        if(empty($erros)) {
            $erroDAO = $this->vooDAO->update($voo);
            if($erroDAO)
               array_push($erros, $erroDAO); 
        }

        return $erros;
    }

    public function excluir(int $id) {
        return $this->vooDAO->excluir($id);
    }

    
}

?>