<?php

require_once(__DIR__ . "/../model/Voo.php");

class Poltrona {
    
    private ?int $id;
    private ?string $numero;
    private ?string $classe;
    private ?Voo $voo;


    public function getId(): ?int
    {
        return $this->id;
    }

    public function setId(?int $id): self
    {
        $this->id = $id;

        return $this;
    }

    public function getNumero(): ?string
    {
        return $this->numero;
    }

    public function setNumero(?string $numero): self
    {
        $this->numero = $numero;

        return $this;
    }

    public function getClasse(): ?string
    {
        return $this->classe;
    }

    public function setClasse(?string $classe): self
    {
        $this->classe = $classe;

        return $this;
    }

    public function getVoo(): ?Voo
    {
        return $this->voo;
    }

    public function setVoo(?Voo $voo): self
    {
        $this->voo = $voo;

        return $this;
    }
}