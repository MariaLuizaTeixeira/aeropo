<?php

class Voo {
    private ?int $id;
    private ?string $destino;
    private ?string $origem;
    private ?DateTime $saida;
    private ?DateTime $chegada;
    private ?string $imagem;
    private ?float $valor;

    public function getId(): int
    {
        return $this->id;
    }

    public function setId(int $id): self
    {
        $this->id = $id;

        return $this;
    }

    public function getDestino(): string
    {
        return $this->destino;
    }

    public function setDestino(string $destino): self
    {
        $this->destino = $destino;

        return $this;
    }

    public function getOrigem(): string
    {
        return $this->origem;
    }

    public function setOrigem(string $origem): self
    {
        $this->origem = $origem;

        return $this;
    }

    public function getSaida(): DateTime
    {
        return $this->saida;
    }

    public function setSaida(DateTime $saida): self
    {
        $this->saida = $saida;

        return $this;
    }

    public function getChegada(): DateTime
    {
        return $this->chegada;
    }

    public function setChegada(DateTime $chegada): self
    {
        $this->chegada = $chegada;

        return $this;
    }

    public function getImagem(): ?string
    {
        return $this->imagem;
    }

    public function setImagem(?string $imagem): self
    {
        $this->imagem = $imagem;

        return $this;
    }

    public function getValor(): ?float
    {
        return $this->valor;
    }

    public function setValor(?float $valor): self
    {
        $this->valor = $valor;

        return $this;
    }

}

?>