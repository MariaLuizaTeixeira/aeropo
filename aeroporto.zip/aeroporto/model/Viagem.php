<?php

require_once(__DIR__ . "/Cliente.php");
require_once(__DIR__ . "/Voo.php");
require_once(__DIR__ . "/Poltrona.php");

class Viagem {
    private ?int $id;
    private ?Cliente $cliente;
    private ?Poltrona $poltrona;
    private ?Voo $voo;

    public function getId(): int
    {
        return $this->id;
    }

    public function setId(int $id): self
    {
        $this->id = $id;

        return $this;
    }

    public function getCliente(): ?Cliente
    {
        return $this->cliente;
    }

    public function setCliente(?Cliente $cliente): self
    {
        $this->cliente = $cliente;

        return $this;
    }

    public function getVoo(): ?Voo
    {
        return $this->voo;
    }

    public function setVoo(?Voo $voo): self
    {
        $this->voo = $voo;

        return $this;
    }

    public function getPoltrona(): ?Poltrona
    {
        return $this->poltrona;
    }

    public function setPoltrona(?Poltrona $poltrona): self
    {
        $this->poltrona = $poltrona;

        return $this;
    }
}

?>
