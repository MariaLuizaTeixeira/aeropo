<?php

require_once(__DIR__ . "/Cliente.php");
require_once(__DIR__ . "/Funcionario.php");
require_once(__DIR__ . "/Voo.php");

class Viagem {
    private ?int $id;
    private ?string $assento;
    private ?bool $pago;
    private ?bool $cancelado;
    private ?Cliente $cliente;
    private ?Funcionario $funcionario;
    private ?Voo $voo;

    public function getId(): int
    {
        return $this->id;
    }

    public function setId(int $id): self
    {
        $this->id = $id;

        return $this;
    }

    public function getAssento(): string
    {
        return $this->assento;
    }

    public function setAssento(string $assento): self
    {
        $this->assento = $assento;

        return $this;
    }

    public function isPago(): bool
    {
        return $this->pago;
    }

    public function setPago(bool $pago): self
    {
        $this->pago = $pago;

        return $this;
    }

    public function isCancelado(): bool
    {
        return $this->cancelado;
    }

    public function setCancelado(bool $cancelado): self
    {
        $this->cancelado = $cancelado;

        return $this;
    }

    public function getCliente(): Cliente
    {
        return $this->cliente;
    }

    public function setCliente(Cliente $cliente): self
    {
        $this->cliente = $cliente;

        return $this;
    }

    public function getFuncionario(): Funcionario
    {
        return $this->funcionario;
    }

    public function setFuncionario(Funcionario $funcionario): self
    {
        $this->funcionario = $funcionario;

        return $this;
    }

    public function getVoo(): Voo
    {
        return $this->voo;
    }

    public function setVoo(Voo $voo): self
    {
        $this->voo = $voo;

        return $this;
    }
}

?>
